package org.truffle.cs.mj.nodes;

public class MJAssignNode {

}
