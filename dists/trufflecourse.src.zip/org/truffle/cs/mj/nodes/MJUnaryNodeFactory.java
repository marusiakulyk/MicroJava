// CheckStyle: start generated
package org.truffle.cs.mj.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import org.truffle.cs.mj.nodes.MJExpressionNode;
import org.truffle.cs.mj.nodes.MJUnaryNode;
import org.truffle.cs.mj.nodes.MJUnaryNode.DecrementNode;
import org.truffle.cs.mj.nodes.MJUnaryNode.IncrementNode;

@GeneratedBy(MJUnaryNode.class)
public final class MJUnaryNodeFactory {

    @GeneratedBy(IncrementNode.class)
    public static final class IncrementNodeGen extends IncrementNode {

        @Child private MJExpressionNode lhs_;
        @CompilationFinal private int state_;

        private IncrementNodeGen(MJExpressionNode lhs) {
            this.lhs_ = lhs;
        }

        @Override
        public Object executeGeneric(VirtualFrame frameValue) {
            int state = state_;
            int lhsValue_;
            try {
                lhsValue_ = this.lhs_.executeI32(frameValue);
            } catch (UnexpectedResultException ex) {
                return executeAndSpecialize(ex.getResult());
            }
            if (state != 0 /* is-active add(int) */) {
                return add(lhsValue_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(lhsValue_);
        }

        @Override
        public int executeI32(VirtualFrame frameValue) {
            int state = state_;
            int lhsValue_;
            try {
                lhsValue_ = this.lhs_.executeI32(frameValue);
            } catch (UnexpectedResultException ex) {
                return executeAndSpecialize(ex.getResult());
            }
            if (state != 0 /* is-active add(int) */) {
                return add(lhsValue_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(lhsValue_);
        }

        private int executeAndSpecialize(Object lhsValue) {
            int state = state_;
            if (lhsValue instanceof Integer) {
                int lhsValue_ = (int) lhsValue;
                this.state_ = state = state | 0b1 /* add-active add(int) */;
                return add(lhsValue_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {this.lhs_}, lhsValue);
        }

        @Override
        public NodeCost getCost() {
            int state = state_;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IncrementNode create(MJExpressionNode lhs) {
            return new IncrementNodeGen(lhs);
        }

    }
    @GeneratedBy(DecrementNode.class)
    public static final class DecrementNodeGen extends DecrementNode {

        @Child private MJExpressionNode lhs_;
        @CompilationFinal private int state_;

        private DecrementNodeGen(MJExpressionNode lhs) {
            this.lhs_ = lhs;
        }

        @Override
        public Object executeGeneric(VirtualFrame frameValue) {
            int state = state_;
            int lhsValue_;
            try {
                lhsValue_ = this.lhs_.executeI32(frameValue);
            } catch (UnexpectedResultException ex) {
                return executeAndSpecialize(ex.getResult());
            }
            if (state != 0 /* is-active add(int) */) {
                return add(lhsValue_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(lhsValue_);
        }

        @Override
        public int executeI32(VirtualFrame frameValue) {
            int state = state_;
            int lhsValue_;
            try {
                lhsValue_ = this.lhs_.executeI32(frameValue);
            } catch (UnexpectedResultException ex) {
                return executeAndSpecialize(ex.getResult());
            }
            if (state != 0 /* is-active add(int) */) {
                return add(lhsValue_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(lhsValue_);
        }

        private int executeAndSpecialize(Object lhsValue) {
            int state = state_;
            if (lhsValue instanceof Integer) {
                int lhsValue_ = (int) lhsValue;
                this.state_ = state = state | 0b1 /* add-active add(int) */;
                return add(lhsValue_);
            }
            throw new UnsupportedSpecializationException(this, new Node[] {this.lhs_}, lhsValue);
        }

        @Override
        public NodeCost getCost() {
            int state = state_;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static DecrementNode create(MJExpressionNode lhs) {
            return new DecrementNodeGen(lhs);
        }

    }
}
